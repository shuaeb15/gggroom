<?php
$this->load->view('templates/_include/header_view1');?>

<div class="related_services product_round">
   <div class="container">
     <div class="col-md-12" style="text-align:center;font-size: 35px;">
       <span class=""><?=$page_data->name?></span>
     </div>
      <div class="col-md-12 col-xs-12">
        <div class="" style="margin-top: 50px;">
            <p><?=$page_data->description?></p>
        </div>
      </div>
   </div>
</div>
