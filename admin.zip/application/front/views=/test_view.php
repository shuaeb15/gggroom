<?php //$this->load->view('templates/_include/header_view1');  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?=$title?></title>
  </head>
    <body>
      <div style="background: #ccc;" class="home_header_main">
          <div class="related_services product_round">
             <div class="container">
               <div class="col-md-12" style="text-align:center;font-size: 35px;margin-bottom:20px;margin-top:20px;">
                 <span class="form-title">Shop Verification</span>
               </div>
                <div class="col-md-12 col-xs-12">
                  <html>
                    <head>
                      <title>Shop Verification</title>
                    </head>
                    <!-- <?php $main_image = base_url()."front/images/nochats.png"; ?> -->
                      <div style=text-align:center;><img src="<?=$main_image?>" width=200 height=100 /></div>
                      <p>Please click this link to verification : $ChangePassUrl</p>
                    </html
                </div>
             </div>
          </div>
      </div>
    </body>
