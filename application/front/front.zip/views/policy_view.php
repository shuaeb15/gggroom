<?php $this->load->view('templates/_include/header_view1');  ?>

<div class="related_services product_round">
   <div class="container">
     <div class="col-md-12" style="text-align:center;font-size: 35px;margin-bottom:20px;margin-top:20px;">
       <span class="form-title">POLICY</span>
     </div>
      <div class="col-md-12 col-xs-12">
        <?php
          echo $page_data->description;
        ?>
      </div>
   </div>
</div>
